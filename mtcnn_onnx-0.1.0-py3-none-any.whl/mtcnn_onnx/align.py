from .mtcnn import MTCNN
from PIL import Image

import numpy as np

_mtcnn_model = None
_current_providers = None

def get_mtcnn_model(providers=None):
    global _mtcnn_model, _current_providers
    
    # If providers is None, just return the current model (or init default)
    if providers is None:
        if _mtcnn_model is None:
            _mtcnn_model = MTCNN(crop_size=(112, 112))
        return _mtcnn_model
        
    # If specific providers are requested, re-init ONLY if they differ from current
    if _mtcnn_model is None or _current_providers != providers:
        _mtcnn_model = MTCNN(crop_size=(112, 112), providers=providers)
        _current_providers = providers
        
    return _mtcnn_model

def add_padding(pil_img, top, right, bottom, left, color=(0,0,0)):
    width, height = pil_img.size
    new_width = width + right + left
    new_height = height + top + bottom
    result = Image.new(pil_img.mode, (new_width, new_height), color)
    result.paste(pil_img, (left, top))
    return result

def _to_pil_image(img_input):
    if isinstance(img_input, str):
        return Image.open(img_input).convert('RGB')
    elif isinstance(img_input, Image.Image):
        return img_input.convert('RGB') if img_input.mode != 'RGB' else img_input
    elif isinstance(img_input, np.ndarray):
        # Assume RGB numpy array if it's not a PIL Image or path
        # Note: if it's BGR from cv2, the user should convert it to RGB before passing it.
        return Image.fromarray(img_input)
    else:
        raise ValueError(f"Unsupported input type {type(img_input)}. Must be str (path), PIL.Image, or numpy.ndarray")

def get_aligned_face(inputs, rgb_pil_image=None, providers=None):
    # Maintain backward compatibility with (image_path, rgb_pil_image=...)
    if rgb_pil_image is not None:
        inputs = rgb_pil_image

    is_batch = isinstance(inputs, list)
    input_list = inputs if is_batch else [inputs]
    results = []

    mtcnn = get_mtcnn_model(providers=providers)

    for item in input_list:
        try:
            img = _to_pil_image(item)
            bboxes, faces = mtcnn.align_multi(img, limit=1)
            results.append(faces[0] if len(faces) > 0 else None)
        except Exception as e:
            print(f'Face detection failed due to error: {e}')
            results.append(None)

    return results if is_batch else results[0]
