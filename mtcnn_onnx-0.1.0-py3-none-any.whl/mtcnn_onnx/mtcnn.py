from typing import Tuple
import numpy as np
import onnxruntime as ort
from PIL import Image

import sys
import os

from .box_utils import nms, calibrate_box, get_image_boxes, convert_to_square
from .first_stage import run_first_stage
from .align_trans import get_reference_facial_points, warp_and_crop_face

class MTCNN():
    def __init__(self, crop_size: Tuple[int, int] = (112, 112), providers=None):
        if providers is None:
            providers = ['CUDAExecutionProvider', 'CPUExecutionProvider']
        
        self.crop_size = crop_size
        assert crop_size in [(112, 112), (96, 112)]

        # Get path to the ONNX models bundled with the package
        models_dir = os.path.join(os.path.dirname(__file__), 'models')
        
        pnet_path = os.path.join(models_dir, 'pnet.onnx')
        rnet_path = os.path.join(models_dir, 'rnet.onnx')
        onet_path = os.path.join(models_dir, 'onet.onnx')

        self.pnet = ort.InferenceSession(pnet_path, providers=providers)
        self.rnet = ort.InferenceSession(rnet_path, providers=providers)
        self.onet = ort.InferenceSession(onet_path, providers=providers)

        self.refrence = get_reference_facial_points(default_square=crop_size[0] == crop_size[1])

        self.min_face_size = 20
        self.thresholds = [0.6, 0.7, 0.9]
        self.nms_thresholds = [0.7, 0.7, 0.7]
        self.factor = 0.85

    def align(self, img):
        _, landmarks = self.detect_faces(img, self.min_face_size, self.thresholds, self.nms_thresholds, self.factor)
        if len(landmarks) == 0:
            return None
        facial5points = [[landmarks[0][j], landmarks[0][j + 5]] for j in range(5)]
        warped_face = warp_and_crop_face(np.array(img), facial5points, self.refrence, crop_size=self.crop_size)
        return Image.fromarray(warped_face)

    def align_multi(self, img, limit=None):
        boxes, landmarks = self.detect_faces(img, self.min_face_size, self.thresholds, self.nms_thresholds, self.factor)
        if len(boxes) == 0:
            return [], []
        if limit:
            boxes = boxes[:limit]
            landmarks = landmarks[:limit]
        faces = []
        for landmark in landmarks:
            facial5points = [[landmark[j], landmark[j + 5]] for j in range(5)]
            warped_face = warp_and_crop_face(np.array(img), facial5points, self.refrence, crop_size=self.crop_size)
            faces.append(Image.fromarray(warped_face))
        return boxes, faces

    def detect_faces(self, image, min_face_size, thresholds, nms_thresholds, factor):
        """
        Arguments:
            image: an instance of PIL.Image.
            min_face_size: a float number.
            thresholds: a list of length 3.
            nms_thresholds: a list of length 3.

        Returns:
            two float numpy arrays of shapes [n_boxes, 4] and [n_boxes, 10],
            bounding boxes and facial landmarks.
        """

        # BUILD AN IMAGE PYRAMID
        width, height = image.size
        min_length = min(height, width)

        min_detection_size = 12

        # scales for scaling the image
        scales = []

        m = min_detection_size / min_face_size
        min_length *= m

        factor_count = 0
        while min_length > min_detection_size:
            scales.append(m * factor**factor_count)
            min_length *= factor
            factor_count += 1

        # STAGE 1

        bounding_boxes = []
        
        # run P-Net on different scales
        for s in scales:
            boxes = run_first_stage(image, self.pnet, scale=s, threshold=thresholds[0])
            bounding_boxes.append(boxes)

        # collect boxes (and offsets, and scores) from different scales
        bounding_boxes = [i for i in bounding_boxes if i is not None]
        if len(bounding_boxes) == 0:
            return [], []
        bounding_boxes = np.vstack(bounding_boxes)

        keep = nms(bounding_boxes[:, 0:5], nms_thresholds[0])
        bounding_boxes = bounding_boxes[keep]

        # use offsets predicted by pnet to transform bounding boxes
        bounding_boxes = calibrate_box(bounding_boxes[:, 0:5], bounding_boxes[:, 5:])
        # shape [n_boxes, 5]

        bounding_boxes = convert_to_square(bounding_boxes)
        bounding_boxes[:, 0:4] = np.round(bounding_boxes[:, 0:4])

        # STAGE 2

        img_boxes = get_image_boxes(bounding_boxes, image, size=24)
        
        rnet_input_name = self.rnet.get_inputs()[0].name
        output = self.rnet.run(None, {rnet_input_name: img_boxes})
        
        offsets = output[0]  # shape [n_boxes, 4]
        probs = output[1]  # shape [n_boxes, 2]

        keep = np.where(probs[:, 1] > thresholds[1])[0]
        bounding_boxes = bounding_boxes[keep]
        bounding_boxes[:, 4] = probs[keep, 1].reshape((-1, ))
        offsets = offsets[keep]

        keep = nms(bounding_boxes, nms_thresholds[1])
        bounding_boxes = bounding_boxes[keep]
        bounding_boxes = calibrate_box(bounding_boxes, offsets[keep])
        bounding_boxes = convert_to_square(bounding_boxes)
        bounding_boxes[:, 0:4] = np.round(bounding_boxes[:, 0:4])

        # STAGE 3

        img_boxes = get_image_boxes(bounding_boxes, image, size=48)
        if len(img_boxes) == 0:
            return [], []
            
        onet_input_name = self.onet.get_inputs()[0].name
        output = self.onet.run(None, {onet_input_name: img_boxes})
        
        landmarks = output[0]  # shape [n_boxes, 10]
        offsets = output[1]  # shape [n_boxes, 4]
        probs = output[2]  # shape [n_boxes, 2]

        keep = np.where(probs[:, 1] > thresholds[2])[0]
        bounding_boxes = bounding_boxes[keep]
        bounding_boxes[:, 4] = probs[keep, 1].reshape((-1, ))
        offsets = offsets[keep]
        landmarks = landmarks[keep]

        # compute landmark points
        width_box = bounding_boxes[:, 2] - bounding_boxes[:, 0] + 1.0
        height_box = bounding_boxes[:, 3] - bounding_boxes[:, 1] + 1.0
        xmin, ymin = bounding_boxes[:, 0], bounding_boxes[:, 1]
        landmarks[:, 0:5] = np.expand_dims(xmin, 1) + np.expand_dims(width_box, 1) * landmarks[:, 0:5]
        landmarks[:, 5:10] = np.expand_dims(ymin, 1) + np.expand_dims(height_box, 1) * landmarks[:, 5:10]

        bounding_boxes = calibrate_box(bounding_boxes, offsets)
        keep = nms(bounding_boxes, nms_thresholds[2], mode='min')
        bounding_boxes = bounding_boxes[keep]
        landmarks = landmarks[keep]

        return bounding_boxes, landmarks
